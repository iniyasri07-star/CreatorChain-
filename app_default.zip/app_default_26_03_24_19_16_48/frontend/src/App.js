import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Upload, 
  LayoutDashboard, 
  ShoppingBag, 
  User, 
  LogOut, 
  Search,
  Lock,
  CheckCircle,
  ExternalLink
} from 'lucide-react';
import axios from 'axios';
import ProtectionWrapper from './components/ProtectionWrapper';

const API_BASE = "http://localhost:5000/api";

// --- Components ---

const Navbar = ({ user, logout }) => (
  <nav className="bg-slate-900 border-b border-slate-800 p-4 text-white flex justify-between items-center sticky top-0 z-50">
    <Link to="/" className="flex items-center gap-2 text-xl font-bold text-blue-400">
      <ShieldCheck className="w-8 h-8" />
      VeriContent
    </Link>
    <div className="flex gap-6 items-center">
      <Link to="/marketplace" className="hover:text-blue-400 flex items-center gap-1"><ShoppingBag size={18} /> Marketplace</Link>
      {user ? (
        <>
          <Link to="/dashboard" className="hover:text-blue-400 flex items-center gap-1"><LayoutDashboard size={18} /> Dashboard</Link>
          <button onClick={logout} className="bg-red-500/10 text-red-400 px-4 py-1.5 rounded-lg border border-red-500/20 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1">
            <LogOut size={16} /> Logout
          </button>
        </>
      ) : (
        <Link to="/login" className="bg-blue-600 px-6 py-2 rounded-lg hover:bg-blue-700 transition">Login</Link>
      )}
    </div>
  </nav>
);

const Marketplace = ({ user }) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(`${API_BASE}/marketplace`).then(res => {
      setItems(res.data);
      setLoading(false);
    });
  }, []);

  const handlePurchase = async (id) => {
    const token = localStorage.getItem('token');
    try {
      await axios.post(`${API_BASE}/payments/pay`, { content_id: id }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert("Payment Successful! Access Granted.");
      window.location.reload();
    } catch (err) {
      alert("Please login as a user to purchase.");
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-10">
        <h1 className="text-3xl font-bold text-slate-100">Verified Content Marketplace</h1>
        <div className="relative">
          <Search className="absolute left-3 top-3 text-slate-500" size={20} />
          <input className="bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 w-80 text-white outline-none focus:border-blue-500" placeholder="Search original creators..." />
        </div>
      </div>

      {loading ? <div className="text-slate-400">Loading verified assets...</div> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {items.map(item => {
            const hasAccess = user && item.authorized_users.includes(user.email);
            return (
              <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-slate-600 transition-all shadow-xl">
                <div className="h-48 bg-slate-800 relative group overflow-hidden">
                  {!hasAccess ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center backdrop-blur-md bg-black/40 z-10">
                      <Lock className="text-blue-400 mb-2" size={32} />
                      <p className="text-sm font-medium">Content Locked</p>
                    </div>
                  ) : (
                    <ProtectionWrapper>
                      <img src={`https://picsum.photos/seed/${item.hash}/600/400`} alt="Content" className="w-full h-full object-cover" />
                    </ProtectionWrapper>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-xl text-white">{item.title}</h3>
                    <span className="bg-green-500/10 text-green-400 text-xs px-2 py-1 rounded-full border border-green-500/20 flex items-center gap-1">
                      <CheckCircle size={12} /> Verified
                    </span>
                  </div>
                  <p className="text-slate-400 text-sm mb-4">By: {item.creator}</p>
                  <div className="flex items-center justify-between mt-6">
                    <div className="text-2xl font-bold text-blue-400">₹{item.price}</div>
                    {hasAccess ? (
                       <button className="text-blue-400 text-sm flex items-center gap-1 hover:underline">
                        View Asset <ExternalLink size={14} />
                       </button>
                    ) : (
                       <button 
                        onClick={() => handlePurchase(item.id)}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl transition font-medium"
                       >
                         Unlock Content
                       </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

const Dashboard = ({ user }) => {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [status, setStatus] = useState('');

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title);
    formData.append('price', price);

    const token = localStorage.getItem('token');
    setStatus('Analyzing with AI & Minting NFT...');
    
    try {
      const res = await axios.post(`${API_BASE}/content/upload`, formData, {
        headers: { 
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}` 
        }
      });
      setStatus(`Success! TX: ${res.data.tx_hash.substring(0, 15)}...`);
      alert("Content Minted and Verified!");
    } catch (err) {
      setStatus('Verification Failed: Content may be unoriginal or duplicated.');
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-8 rounded-3xl border border-slate-700">
        <h2 className="text-2xl font-bold text-white mb-6">Hello, {user.email.split('@')[0]}</h2>
        
        {user.role === 'creator' ? (
          <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800">
            <h3 className="text-lg font-bold text-blue-400 mb-4 flex items-center gap-2">
              <Upload size={20} /> Publish Original Content
            </h3>
            <form onSubmit={handleUpload} className="space-y-4">
              <input 
                className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl text-white" 
                placeholder="Content Title" 
                value={title}
                onChange={e => setTitle(e.target.value)}
              />
              <input 
                className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl text-white" 
                placeholder="Price (INR)" 
                type="number"
                value={price}
                onChange={e => setPrice(e.target.value)}
              />
              <div className="border-2 border-dashed border-slate-700 p-8 text-center rounded-2xl">
                <input 
                  type="file" 
                  onChange={e => setFile(e.target.files[0])} 
                  className="mb-2"
                />
                <p className="text-slate-500 text-sm">Upload PNG, JPG, or PDF. AI will verify originality instantly.</p>
              </div>
              <button className="w-full bg-blue-600 p-4 rounded-xl font-bold hover:bg-blue-500 transition shadow-lg shadow-blue-600/20">
                Verify & Mint on Blockchain
              </button>
              {status && <div className="p-4 bg-slate-800 rounded-xl text-sm text-blue-300 font-mono">{status}</div>}
            </form>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-6">
            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800">
              <p className="text-slate-400 text-sm">Owned Assets</p>
              <p className="text-3xl font-bold mt-1">12</p>
            </div>
            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800">
              <p className="text-slate-400 text-sm">Wallets Linked</p>
              <p className="text-3xl font-bold mt-1">1</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const Auth = ({ setAuth }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const endpoint = isLogin ? 'login' : 'register';
    try {
      const res = await axios.post(`${API_BASE}/auth/${endpoint}`, { email, password, role });
      localStorage.setItem('token', res.data.token);
      setAuth({ email, role: res.data.role });
      navigate('/dashboard');
    } catch (err) {
      alert("Auth Error: " + (err.response?.data?.msg || "Server offline"));
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <div className="bg-slate-900 p-10 rounded-3xl border border-slate-800 w-[400px] shadow-2xl">
        <h2 className="text-2xl font-bold mb-8 text-white">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-white" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
          <input className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-white" type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
          {!isLogin && (
            <select className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-white" value={role} onChange={e => setRole(e.target.value)}>
              <option value="user">Content Consumer</option>
              <option value="creator">Independent Creator</option>
            </select>
          )}
          <button className="w-full bg-blue-600 p-3 rounded-xl font-bold mb-4 hover:bg-blue-500 transition">{isLogin ? 'Login' : 'Signup'}</button>
          <p className="text-sm text-slate-400 text-center cursor-pointer" onClick={() => setIsLogin(!isLogin)}>
            {isLogin ? "Don't have an account? Sign up" : "Already have an account? Login"}
          </p>
        </form>
      </div>
    </div>
  );
};

function App() {
  const [user, setUser] = useState(null);

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  return (
    <Router>
      <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-blue-500/30">
        <Navbar user={user} logout={logout} />
        <Routes>
          <Route path="/" element={<div className="h-[80vh] flex flex-col items-center justify-center text-center p-4">
              <h1 className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600 mb-6 leading-tight">Originality Is <br />Your Strongest Asset.</h1>
              <p className="max-w-2xl text-slate-400 text-xl mb-10">VeriContent protects independent creators with AI-driven originality checks and immutable blockchain proof of ownership.</p>
              <div className="flex gap-4">
                <Link to="/marketplace" className="bg-blue-600 px-8 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-blue-500 transition"><ShoppingBag /> Browse Marketplace</Link>
                <Link to="/login" className="bg-slate-800 border border-slate-700 px-8 py-3 rounded-2xl font-bold hover:bg-slate-700 transition">Get Started</Link>
              </div>
            </div>} />
          <Route path="/marketplace" element={<Marketplace user={user} />} />
          <Route path="/dashboard" element={user ? <Dashboard user={user} /> : <Auth setAuth={setUser} />} />
          <Route path="/login" element={<Auth setAuth={setUser} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
