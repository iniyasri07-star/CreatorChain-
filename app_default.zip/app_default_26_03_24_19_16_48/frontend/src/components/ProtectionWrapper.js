import React, { useEffect } from 'react';

/**
 * ProtectionWrapper provides visual and behavioral security 
 * to prevent easy content theft (right-click, selection, screenshots).
 */
const ProtectionWrapper = ({ children, isProtected = true }) => {
  useEffect(() => {
    if (!isProtected) return;

    const handleContextMenu = (e) => e.preventDefault();
    const handleKeyDown = (e) => {
      // Disable PrintScreen, Ctrl+S, Ctrl+U, Ctrl+Shift+I
      if (
        e.key === 'PrintScreen' || 
        (e.ctrlKey && (e.key === 's' || e.key === 'u' || e.key === 'c' || e.key === 'v')) ||
        (e.ctrlKey && e.shiftKey && e.key === 'I')
      ) {
        e.preventDefault();
        alert("Content protection is active.");
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isProtected]);

  return (
    <div className={`relative ${isProtected ? 'select-none' : ''}`}>
      {/* Visual Watermark Overlay */}
      {isProtected && (
        <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden opacity-5 flex flex-wrap gap-10 items-center justify-center rotate-[-30deg]">
          {Array(20).fill(0).map((_, i) => (
            <span key={i} className="text-4xl font-bold whitespace-nowrap">VERICONTENT SECURE</span>
          ))}
        </div>
      )}
      {children}
      <style>{`
        @media print {
          body { display: none; }
        }
        .select-none {
          -webkit-touch-callout: none;
          -webkit-user-select: none;
          -khtml-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
        }
      `}</style>
    </div>
  );
};

export default ProtectionWrapper;
