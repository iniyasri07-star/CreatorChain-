from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
from dotenv import load_dotenv

from utils.ai_handler import AIHandler
from utils.blockchain_handler import BlockchainHandler

load_dotenv()

app = Flask(__name__)
CORS(app)

app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'dev-secret-key')
jwt = JWTManager(app)

# In-memory mock DB for demonstration (Use MongoDB in production)
users_db = {}
content_db = []

ai_handler = AIHandler()
bc_handler = BlockchainHandler()

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    role = data.get('role', 'user') # 'creator' or 'user'

    if email in users_db:
        return jsonify({"msg": "User already exists"}), 400

    users_db[email] = {
        "password": generate_password_hash(password),
        "role": role,
        "address": data.get('address', '0x0000000000000000000000000000000000000000')
    }
    
    token = create_access_token(identity=email)
    return jsonify({"token": token, "role": role}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    user = users_db.get(email)
    if user and check_password_hash(user['password'], password):
        token = create_access_token(identity=email)
        return jsonify({"token": token, "role": user['role']}), 200

    return jsonify({"msg": "Invalid credentials"}), 401

@app.route('/api/content/upload', methods=['POST'])
@jwt_required()
def upload_content():
    if 'file' not in request.files:
        return jsonify({"msg": "No file uploaded"}), 400
    
    file = request.files['file']
    title = request.form.get('title')
    price = request.form.get('price')
    creator_email = get_jwt_identity()
    user_data = users_db.get(creator_email)

    content_bytes = file.read()
    content_hash = ai_handler.get_content_hash(content_bytes)

    # 1. AI Verification
    is_original, confidence = ai_handler.analyze_content(content_bytes)
    
    if not is_original:
        return jsonify({"msg": "Content flagged as duplicate/AI-generated", "confidence": confidence}), 403

    # 2. Blockchain Uniqueness Check
    if bc_handler.is_hash_on_chain(content_hash):
        return jsonify({"msg": "Content hash already detected on blockchain"}), 409

    # 3. Simulate Blockchain Minting
    try:
        tx_hash = bc_handler.mint_nft(user_data['address'], f"ipfs://{content_hash}", content_hash)
    except Exception as e:
        print(f"BC Error: {e}")
        tx_hash = "0x-simulated-tx-hash-12345"

    content_item = {
        "id": len(content_db) + 1,
        "title": title,
        "hash": content_hash,
        "creator": creator_email,
        "price": price,
        "tx_hash": tx_hash,
        "timestamp": datetime.now().isoformat(),
        "is_original": True,
        "authorized_users": [creator_email]
    }
    content_db.append(content_item)

    return jsonify({
        "msg": "Content verified and minted successfully",
        "tx_hash": tx_hash,
        "content_id": content_item['id']
    }), 201

@app.route('/api/marketplace', methods=['GET'])
def get_marketplace():
    return jsonify(content_db), 200

@app.route('/api/payments/pay', methods=['POST'])
@jwt_required()
def process_payment():
    data = request.json
    content_id = data.get('content_id')
    user_email = get_jwt_identity()

    # Simulate Gateway Interaction
    payment_status = "SUCCESS" 
    
    if payment_status == "SUCCESS":
        for item in content_db:
            if item['id'] == content_id:
                if user_email not in item['authorized_users']:
                    item['authorized_users'].append(user_email)
                return jsonify({"msg": "Access granted"}), 200

    return jsonify({"msg": "Payment failed"}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
