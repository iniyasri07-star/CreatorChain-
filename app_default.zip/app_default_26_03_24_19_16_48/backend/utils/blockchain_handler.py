import os
from web3 import Web3
from dotenv import load_dotenv

load_dotenv()

class BlockchainHandler:
    def __init__(self):
        self.w3 = Web3(Web3.HTTPProvider(os.getenv('BLOCKCHAIN_PROVIDER_URL')))
        self.private_key = os.getenv('PRIVATE_KEY')
        self.account = self.w3.eth.account.from_key(self.private_key)
        self.contract_address = os.getenv('CONTRACT_ADDRESS')
        
        # Minified ABI for VeriContentNFT (only important functions)
        self.abi = [
            {"inputs":[{"internalType":"address","name":"creator","type":"address"},{"internalType":"string","name":"tokenURI","type":"string"},{"internalType":"string","name":"contentHashStr","type":"string"}],"name":"mintContent","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},
            {"inputs":[{"internalType":"string","name":"contentHashStr","type":"string"}],"name":"verifyHash","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"}
        ]
        
        if self.contract_address:
            self.contract = self.w3.eth.contract(address=self.contract_address, abi=self.abi)

    def mint_nft(self, creator_address, token_uri, content_hash):
        if not self.contract:
            return None

        nonce = self.w3.eth.get_transaction_count(self.account.address)
        
        txn = self.contract.functions.mintContent(
            creator_address, 
            token_uri, 
            content_hash
        ).build_transaction({
            'chainId': self.w3.eth.chain_id,
            'gas': 500000,
            'gasPrice': self.w3.to_wei('20', 'gwei'),
            'nonce': nonce,
        })

        signed_txn = self.w3.eth.account.sign_transaction(txn, private_key=self.private_key)
        tx_hash = self.w3.eth.send_raw_transaction(signed_txn.rawTransaction)
        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash)
        
        return receipt.transactionHash.hex()

    def is_hash_on_chain(self, content_hash):
        if not self.contract: return False
        try:
            return self.contract.functions.verifyHash(content_hash).call()
        except:
            return False
