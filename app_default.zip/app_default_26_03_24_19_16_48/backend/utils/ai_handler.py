import joblib
import numpy as np
import os
import hashlib

class AIHandler:
    def __init__(self):
        model_path = os.path.join(os.path.dirname(__file__), 'rf_model.joblib')
        if os.path.exists(model_path):
            self.model = joblib.load(model_path)
        else:
            self.model = None

    def calculate_entropy(self, data):
        if not data: return 0
        from collections import Counter
        import math
        counts = Counter(data)
        probs = [c / len(data) for c in counts.values()]
        return -sum(p * math.log(p, 2) for p in probs)

    def analyze_content(self, content_bytes):
        """
        Analyzes content for originality.
        Returns (is_original, confidence_score)
        """
        if not self.model:
            # Fallback if model isn't trained
            return True, 0.85

        # Feature extraction
        entropy = self.calculate_entropy(content_bytes)
        compression_ratio = len(content_bytes) / (len(set(content_bytes)) + 1)
        metadata_quality = 0.9 # Mock
        duplication_score = 0.05 # Mock

        features = np.array([[entropy, compression_ratio, metadata_quality, duplication_score]])
        prediction = self.model.predict(features)[0]
        probability = self.model.predict_proba(features)[0][1]

        return bool(prediction), float(probability)

    @staticmethod
    def get_content_hash(content_bytes):
        return hashlib.sha256(content_bytes).hexdigest()
