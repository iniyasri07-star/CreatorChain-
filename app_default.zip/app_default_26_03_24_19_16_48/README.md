# VeriContent - Blockchain & AI Powered Content Marketplace

VeriContent is a secure marketplace designed for independent creators. It solves the problem of digital content piracy and attribution using two layers:
1.  **AI Layer**: Uses a Random Forest Classifier to analyze file entropy and features to detect AI-generated or low-effort duplicates.
2.  **Blockchain Layer**: Mints an ERC721 NFT for every unique piece of content, ensuring an immutable record of ownership on-chain.

## Features
- **Originality Check**: AI verification of file metadata and structure before publication.
- **Blockchain Minting**: Automatic NFT creation on a Sepolia/Ethereum compatible chain.
- **Content Protection**: Advanced React-based protection (right-click disable, print-screen blocking, visual watermarks).
- **Pay-before-View**: Mock payment integration that unlocks original high-res content.
- **Role-based Auth**: Dedicated dashboards for Creators and Users.

## Prerequisites
- **Node.js**: v18.0 or later
- **Python**: v3.9 or later
- **MongoDB**: Local instance running at `mongodb://localhost:27017`
- **Smart Contract Deployment**: Requires a local blockchain (like Ganache) or an Infura/Alchemy endpoint.

## Installation

### 1. Model Training
Train the initial AI classifier:
    python ml_model/train_rf.py

### 2. Backend Setup
    cd backend
    pip install -r ../requirements.txt
    python app.py

### 3. Frontend Setup
    cd frontend
    npm install
    npm start

## Configuration
Edit `.env` in the root (or copy provided values) to match your environment:
- `MONGO_URI`: Your MongoDB connection string.
- `PRIVATE_KEY`: Ethereum private key for minting transaction signing.
- `CONTRACT_ADDRESS`: The deployed `VeriContentNFT.sol` address.

## Usage
1.  **Register** as a "Independent Creator".
2.  **Upload** a file. The system will calculate its hash and entropy.
3.  If verified, the file is **minted** as an NFT.
4.  Switch to a **User Account** to browse the marketplace.
5.  Click **Unlock Content** to simulate a payment and gain view access to the high-res asset.

## Project Architecture
- `backend/app.py`: Main Flask controller handling auth, uploads, and payments.
- `backend/utils/ai_handler.py`: Scikit-learn integration for file feature analysis.
- `frontend/src/ProtectionWrapper.js`: React higher-order component for preventing content theft.
- `blockchain/VeriContentNFT.sol`: Solidity contract for content hashing and ownership.
