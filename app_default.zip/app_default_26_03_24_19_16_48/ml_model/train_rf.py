import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib
import os

def generate_mock_data(n_samples=1000):
    """
    Generates synthetic data for content features:
    - entropy: higher for original content
    - compression_ratio: original vs repeated patterns
    - metadata_completeness: 0 to 1
    - duplicate_shingles: lower for original content
    """
    np.random.seed(42)
    
    entropy = np.random.uniform(0.5, 1.0, n_samples)
    compression_ratio = np.random.uniform(1.2, 5.0, n_samples)
    metadata_quality = np.random.uniform(0.1, 1.0, n_samples)
    duplication_score = np.random.uniform(0.0, 0.4, n_samples)
    
    # Original content (Label 1) usually has higher entropy and low duplication
    labels = np.where((entropy > 0.7) & (duplication_score < 0.2), 1, 0)
    
    # Add noise
    noise = np.random.choice([0, 1], size=n_samples, p=[0.95, 0.05])
    labels = np.logical_xor(labels, noise).astype(int)

    df = pd.DataFrame({
        'entropy': entropy,
        'compression_ratio': compression_ratio,
        'metadata_quality': metadata_quality,
        'duplication_score': duplication_score,
        'is_original': labels
    })
    return df

def train_model():
    print("Generating training data...")
    df = generate_mock_data()
    
    X = df.drop('is_original', axis=1)
    y = df['is_original']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print("Training Random Forest Classifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Ensure model directory exists
    os.makedirs('backend/utils', exist_ok=True)
    joblib.dump(model, 'backend/utils/rf_model.joblib')
    print("Model saved to backend/utils/rf_model.joblib")

if __name__ == "__main__":
    train_model()
