// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract VeriContentNFT is ERC721URIStorage, Ownable {
    uint256 private _nextTokenId;
    
    // Mapping from content hash to bool to ensure uniqueness
    mapping(bytes32 => bool) private _contentHashes;

    event ContentMinted(address indexed creator, uint256 tokenId, string contentHash);

    constructor() ERC721("VeriContent", "VCNT") Ownable(msg.sender) {}

    function mintContent(address creator, string memory tokenURI, string memory contentHashStr) public returns (uint256) {
        bytes32 contentHash = keccak256(abi.encodePacked(contentHashStr));
        require(!_contentHashes[contentHash], "Content already exists on blockchain");

        uint256 tokenId = _nextTokenId++;
        _safeMint(creator, tokenId);
        _setTokenURI(tokenId, tokenURI);
        _contentHashes[contentHash] = true;

        emit ContentMinted(creator, tokenId, contentHashStr);
        return tokenId;
    }

    function verifyHash(string memory contentHashStr) public view returns (bool) {
        return _contentHashes[keccak256(abi.encodePacked(contentHashStr))];
    }
}
